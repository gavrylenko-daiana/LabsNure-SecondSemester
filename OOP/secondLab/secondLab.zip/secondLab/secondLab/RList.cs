namespace secondLab;

class RList
{
    public int? Info;
    public RList? Next;

    // 1 Конструктор з одним параметром (число); 
    public RList(int? info)
    {
        Info = info;
    }

    // 3 Конструктор копіювання;
    public RList(RList other)
    {
        if (other == null) throw new ArgumentNullException(nameof(other));

        Info = other.Info;
        Next = other.Next;
    }

    // 4 Метод додавання нового елементу першим у список;
    public void AddFirst(int item)
    {
        if (item <= 0) throw new ArgumentOutOfRangeException(nameof(item));

        RList newNode = new RList(Info);
        newNode.Next = Next;
        Info = item;
        Next = newNode;
    }

    // 8 Рекурсивний метод додавання нового елемента n-ним у список;
    public void AddNewElementByIndex(int i, int n)
    {
        if (n < 0) throw new ArgumentOutOfRangeException(nameof(n));

        if (n == 0)
        {
            AddFirst(i);
            return;
        }

        if (Next == null)
            Next = new RList(i);
        else
            Next.AddNewElementByIndex(i, n - 1);
    }

    // 18 Метод видалення елемента із заданим значенням (першого з кількох);
    public void Remove(int i)
    {
        if (Info == i)
        {
            Info = Next?.Info;
            Next = Next?.Next;
            return;
        }

        Next?.Remove(i);
    }

    // 25 Метод видалення всіх елементів списку;
    public void Clear()
    {
        Info = null;
        Next = null;
    }

    // 29 Не рекурсивний метод друку елементів списку у зворотному порядку у стовпець;
    public void PrintReverse()
    {
        int count = 0;
        RList? current = this;
        while (current != null)
        {
            count++;
            current = current.Next;
        }

        for (int i = count; i > 0; i--)
        {
            current = this;
            for (int j = 1; j < i; j++)
            {
                current = current?.Next;
            }

            Console.WriteLine(current?.Info);
        }
    }

    // 41 Метод пошуку елемента із заданим значенням (результат - номер знайденого елемента у списку);
    public int Find(int i)
    {
        int index = 0;
        RList? current = this;
        while (current != null)
        {
            if (current.Info == i) return index;
            index++;
            current = current.Next;
        }

        return -1;
    }

    // 51 Властивість Last для зчитування та установки значення останнього елемента в списку;
    public int? Last
    {
        get
        {
            if (Next == null) return Info;
            RList? current = this;
            while (current.Next != null) current = current.Next;
            return current.Info;
        }
        set
        {
            if (Next == null) Info = value;
            RList? current = this;
            while (current.Next != null) current = current.Next;
            current.Info = value;
        }
    }

    // 66 Перевизначити для списку  операцію ++
    public static RList operator ++(RList list)
    {
        if (list == null) throw new ArgumentNullException(nameof(list));
        if (list.Next == null) throw new InvalidOperationException();
        RList? current = list;
        while (current != null)
        {
            current.Info++;
            current = current.Next;
        }

        return list;
    }

    // 79 Перевизначити для списку будь-яку операцію
    public static RList? operator +(RList list, int value)
    {
        if (list.Info == null) throw new ArgumentNullException(nameof(list));
        if (value == 0) return list;

        RList? current = list;

        while (current != null)
        {
            current.Info = (current.Info + value);
            current = current.Next;
        }
        return list;
    }

    public void PrintList()
    {
        // if (Info == null) throw new ArgumentNullException(nameof(Info));
        Console.Write($"{Info} ");
        Next?.PrintList();
    }
}